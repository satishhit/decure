define([
    'Yireo_GoogleTagManager2/js/generic'
], function (Actions) {
    'use strict';

    // @todo
});
