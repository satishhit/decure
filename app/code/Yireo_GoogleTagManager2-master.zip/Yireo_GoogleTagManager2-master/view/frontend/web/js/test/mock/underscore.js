define([], function() {
    return {
        'isEmpty': function() {
            return false;
        }
    };
});