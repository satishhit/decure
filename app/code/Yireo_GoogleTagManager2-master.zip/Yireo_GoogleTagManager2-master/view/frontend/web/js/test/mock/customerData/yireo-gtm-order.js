define([], function() {
    return function() {
        return {
            'data_id': 0
        };

    };
});