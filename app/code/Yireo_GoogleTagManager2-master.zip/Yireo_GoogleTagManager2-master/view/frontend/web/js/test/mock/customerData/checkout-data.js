define([], function() {
    return {
        'subscribe': function() {}
    };
});