define([], function () {
    var cart = function () {
        return {
            'subscribe': function () {
            }
        };
    };

    cart.subscribe = function() {};

    return cart;
});