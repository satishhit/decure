define([], function() {
   return {
      'extend': function() {}
   };
});